<?php
    $nome = $_GET['nome'];
    echo "Nome: $nome <br>";

    $senha = $_GET['senha'];
    echo "Senha digitada: $senha <br>";

    $senhaC = "marwin2022";

     if($senha != $senhaC){
        echo "Acesso negado";
    }else if($senha == $senhaC){
        echo "Acesso Permitido";
    }
    
?>