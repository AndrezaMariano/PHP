<?php
    $n1 = $_GET['n1'];
    echo "Nota 1: $n1 <br>";

    $n2 = $_GET['n2'];
    echo "Nota 2: $n2 <br>";

    $n3 = $_GET['n3'];
    echo "Nota 3: $n3 <br>";
   
    $media = ($n1+$n2+$n3)/3;
    
    if($media >= 6.0){
        $resu = "Aprovado";
    }elseif($media >= 4.0){
        $resu = "de Recuperação";
    }else if($media <= 4.0){
        $resu = "Reprovado";
    }

    echo "$media, Você está $resu";
?>