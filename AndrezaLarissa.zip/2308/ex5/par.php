<?php
    $valor = $_GET['valor'];
    echo "Valor: $valor <br>";
    
    if($valor % 2 == 0){
        echo "$valor é par";
    }else{
        echo "$valor é ímpar";
    }
    
?>