<?php
    $dt = $_GET['dt'];
    echo "Distância Total: $dt <br>";

    $com = $_GET['com'];
    echo "Combustível Gasto: $com <br>";

    $ca = $dt/$com;
    echo "$ca"
    
?>