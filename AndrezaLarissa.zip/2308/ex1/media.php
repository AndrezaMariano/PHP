<?php
    $nome = $_GET['nome'];
    echo "Nome: $nome <br>";

    $sal = $_GET['sal'];
    echo "Salário: $sal <br>";

    $tot = $_GET['tot'];
    echo "Total: $tot <br>";

    $sala = $sal + ($tot * 15/100);

    echo "$sala"
    
?>